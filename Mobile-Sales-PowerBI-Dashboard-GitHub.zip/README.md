# 📱 Mobile Sales & Transaction Analysis Dashboard

## 📊 Project Overview

This project is an interactive **Mobile Sales & Transaction Analysis Dashboard** developed using **Microsoft Power BI**.

The dashboard transforms mobile sales data into interactive visual insights covering sales performance, quantity, transactions, customer ratings, payment methods, brands, mobile models, cities, and time-based trends.

This project was completed as part of my practical Power BI learning journey with **SkillCourse under the guidance of Satish Dhawale, Founder of SkillCourse**.

## 🎯 Objectives

- Analyze overall mobile sales performance
- Track total sales, quantity, transactions, and average sales
- Compare sales performance across mobile brands and models
- Analyze city-wise sales
- Understand customer rating distribution
- Analyze transaction methods
- Identify monthly and day-wise sales trends
- Build an interactive and user-friendly Power BI dashboard

## 📌 Key KPIs

| KPI | Value |
|---|---:|
| Total Sales | 769M |
| Total Quantity | 19K |
| Total Transactions | 4K |
| Average Sales | 40K |

## 📈 Dashboard Visualizations

- **Total Quantity by Month** – identifies monthly quantity trends
- **Total Sales by City** – geographic analysis of sales
- **Customer Ratings** – distribution of ratings from 1 to 5
- **Transactions by Payment Method** – comparison of UPI, Debit Card, Credit Card and Cash
- **Total Sales by Mobile Model** – model-wise sales comparison
- **Total Sales by Day Name** – day-wise sales trend
- **Brand-wise Analysis** – comparison of major mobile brands
- **Interactive Slicers** – Mobile Model, Payment Method, Brand and Month

## 🛠️ Tools & Technologies

- Microsoft Power BI
- Power Query
- Data Visualization
- Data Analysis
- Interactive Slicers
- KPI Cards
- Charts & Graphs
- Map Visualization

## 📚 Skills Practiced

- Data cleaning and transformation
- Data visualization
- KPI creation
- Interactive filtering
- Trend analysis
- Geographic analysis
- Business-oriented dashboard design
- Data storytelling

## 🖼️ Dashboard Preview

![Mobile Sales Power BI Dashboard](dashboard_preview.png)

## 🎓 Learning Source

This project was created as part of my Power BI learning journey with:

**SkillCourse**  
**Mentor:** Satish Dhawale – Founder, SkillCourse

The project helped me gain practical experience in converting raw data into an interactive business dashboard.

## 🚀 Future Improvements

- Add more advanced DAX measures
- Add additional business KPIs
- Improve drill-through analysis
- Add more detailed product and customer analysis
- Publish and share the interactive Power BI report where appropriate

## 👨‍💻 Author

**Tilak S Badami**

Electronics & Communication Engineering | Aspiring Data Analyst

Skills: **Excel | Power BI | SQL | Python | Data Analytics**

---

⭐ If you find this project useful, feel free to explore the repository and connect with me on LinkedIn.
